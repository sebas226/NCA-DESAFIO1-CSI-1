package grupo4_biblioteca;

/**
 * Esta clase representa un libro que está físicamente en la biblioteca.
 */
public class LibroFisico extends Libro {
    
    // Estantería o zona donde está el libro.
    private String ubicacion;

    // Estado del libro, por ejemplo nuevo, usado, etc.
    private String estado;

    public LibroFisico(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor, String ubicacion, String estado) {
        // Primero guardamos los datos comunes del libro.
        super(idLibro, titulo, genero, cantidadTotal, cantidadDisponible, idAutor);

        // Después guardamos los datos propios del libro físico.
        this.ubicacion = ubicacion;
        this.estado = estado;
    }

    // Devuelve dónde está colocado el libro.
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    // Devuelve el estado del libro.
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String obtenerTipoLibro() {
        // Este texto aparece en la tabla del catálogo.
        return "Físico";
    }
}
