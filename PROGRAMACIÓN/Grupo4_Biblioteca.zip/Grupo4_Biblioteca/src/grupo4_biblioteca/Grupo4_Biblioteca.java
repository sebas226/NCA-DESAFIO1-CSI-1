package grupo4_biblioteca;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Clase principal. Desde aqui empieza el programa Swing.
 */
public class Grupo4_Biblioteca {

    public static void main(String[] args) {
        configurarAspectoVentanas();

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                PantallaPrincipal pantallaLogin = new PantallaPrincipal();
                pantallaLogin.setVisible(true);
            }
        });
    }

    private static void configurarAspectoVentanas() {
        UIManager.put("OptionPane.okButtonText", "Aceptar");
        UIManager.put("OptionPane.cancelButtonText", "Cancelar");
        UIManager.put("OptionPane.yesButtonText", "Sí");
        UIManager.put("OptionPane.noButtonText", "No");

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            System.out.println("No se pudo aplicar el aspecto visual del sistema: " + ex.getMessage());
        }

        UIManager.put("OptionPane.okButtonText", "Aceptar");
        UIManager.put("OptionPane.cancelButtonText", "Cancelar");
        UIManager.put("OptionPane.yesButtonText", "Sí");
        UIManager.put("OptionPane.noButtonText", "No");
    }
}
