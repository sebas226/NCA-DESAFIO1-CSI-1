package grupo4_biblioteca;

/**
 * Esta clase guarda los datos que tienen todos los libros.
 * Es abstracta porque no se usa sola: se usa con LibroFisico o LibroDigital.
 */
public abstract class Libro {
    
    // Datos básicos que vienen de la tabla Libro.
    private int idLibro;
    private String titulo;
    private String genero;
    private int cantidadTotal;
    private int cantidadDisponible;
    private int idAutor;

    public Libro(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor) {
        // Guardamos en el objeto los datos que llegan al constructor.
        this.idLibro = idLibro;
        this.titulo = titulo;
        this.genero = genero;
        this.cantidadTotal = cantidadTotal;
        this.cantidadDisponible = cantidadDisponible;
        this.idAutor = idAutor;
    }

    // Devuelve el id del libro.
    public int getIdLibro() { return idLibro; }
    public void setIdLibro(int idLibro) { this.idLibro = idLibro; }

    // Devuelve el título del libro.
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    // Devuelve el género del libro.
    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    // Devuelve cuántas copias hay en total.
    public int getCantidadTotal() { return cantidadTotal; }
    public void setCantidadTotal(int cantidadTotal) { this.cantidadTotal = cantidadTotal; }

    // Devuelve cuántas copias quedan disponibles.
    public int getCantidadDisponible() { return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) { this.cantidadDisponible = cantidadDisponible; }

    // Devuelve el id del autor.
    public int getIdAutor() { return idAutor; }
    public void setIdAutor(int idAutor) { this.idAutor = idAutor; }
    
    // Cada clase hija devuelve su tipo: "Físico" o "Digital".
    public abstract String obtenerTipoLibro();
}
