package grupo4_biblioteca;

/**
 * Esta clase guarda los datos de una persona registrada en la biblioteca.
 */
public class Usuario {
    
    // Datos del usuario.
    private int idUsuario;
    private String nombreUsuario;
    private String email;
    private String contrasena;
    private String telefono;
    private String direccion;

    public Usuario(int idUsuario, String nombreUsuario, String email, String contrasena, String telefono, String direccion) {
        // Guardamos en el objeto los datos que llegan al constructor.
        this.idUsuario = idUsuario;
        setNombreUsuario(nombreUsuario);
        this.email = email;
        setContrasena(contrasena);
        this.telefono = telefono;
        this.direccion = direccion;
    }

    // Devuelve el id del usuario.
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    // Devuelve el nombre de usuario.
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) {
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de usuario no puede estar vacio.");
        }
        this.nombreUsuario = nombreUsuario;
    }

    // Devuelve el email.
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    // Devuelve la contraseña.
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) {
        if (contrasena == null || contrasena.trim().isEmpty()) {
            throw new IllegalArgumentException("La contrasena no puede estar vacia.");
        }
        this.contrasena = contrasena;
    }

    // Devuelve el teléfono.
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    // Devuelve la dirección.
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
}
