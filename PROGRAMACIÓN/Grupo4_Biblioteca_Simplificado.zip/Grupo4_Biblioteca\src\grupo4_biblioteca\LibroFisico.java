package grupo4_biblioteca;

import java.io.Serializable;

public class LibroFisico extends Libro implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String ubicacion;
    private String estado;

    public LibroFisico(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor, String ubicacion, String estado) {
        super(idLibro, titulo, genero, cantidadTotal, cantidadDisponible, idAutor);
        this.ubicacion = ubicacion;
        this.estado = estado;
    }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String obtenerTipoLibro() {
        return "Físico";
    }
}
