package grupo4_biblioteca;

import java.io.Serializable;

public class LibroDigital extends Libro implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String formato;
    private int tamanoArchivo;
    private String enlaceDescarga;

    public LibroDigital(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor, String formato, int tamanoArchivo, String enlaceDescarga) {
        super(idLibro, titulo, genero, cantidadTotal, cantidadDisponible, idAutor);
        this.formato = formato;
        this.tamanoArchivo = tamanoArchivo;
        this.enlaceDescarga = enlaceDescarga;
    }

    public String getFormato() { return formato; }
    public void setFormato(String formato) { this.formato = formato; }

    public int getTamanoArchivo() { return tamanoArchivo; }
    public void setTamanoArchivo(int tamanoArchivo) { this.tamanoArchivo = tamanoArchivo; }

    public String getEnlaceDescarga() { return enlaceDescarga; }
    public void setEnlaceDescarga(String enlaceDescarga) { this.enlaceDescarga = enlaceDescarga; }

    @Override
    public String obtenerTipoLibro() {
        return "Digital";
    }
}
