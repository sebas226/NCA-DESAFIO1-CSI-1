package grupo4_biblioteca;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Ventana para registrar un nuevo usuario.
 * Simplificada para 1º DAM.
 */
public class RegistroUsuario extends JDialog {

    private JTextField txtNombre;
    private JTextField txtEmail;
    private JPasswordField txtContrasena;
    private JTextField txtTelefono;
    private JTextField txtDireccion;
    private JButton btnGuardar;
    private JButton btnCancelar;

    public RegistroUsuario(JFrame parent) {
        super(parent, "Registro de Nuevo Usuario", true); // true = Modal (bloquea la pantalla de atrás)
        setSize(350, 400);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(parent);

        // Usamos GridLayout para que quede ordenado fácilmente (Filas, Columnas, EspacioH, EspacioV)
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Márgenes

        // --- CREAR CAMPOS ---
        
        panel.add(new JLabel("Nombre de Usuario:"));
        txtNombre = new JTextField();
        panel.add(txtNombre);

        panel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        panel.add(txtEmail);

        panel.add(new JLabel("Contraseña:"));
        txtContrasena = new JPasswordField();
        panel.add(txtContrasena);

        panel.add(new JLabel("Teléfono:"));
        txtTelefono = new JTextField();
        panel.add(txtTelefono);

        panel.add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        panel.add(txtDireccion);

        // Botones
        btnGuardar = new JButton("Guardar");
        btnCancelar = new JButton("Cancelar");
        panel.add(btnGuardar);
        panel.add(btnCancelar);

        add(panel);

        // --- ACCIONES DE LOS BOTONES ---

        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 1. Recoger datos
                String nombre = txtNombre.getText();
                String email = txtEmail.getText();
                String contrasena = new String(txtContrasena.getPassword());
                String telefono = txtTelefono.getText();
                String direccion = txtDireccion.getText();

                // Validación simple: comprobar que no estén vacíos
                if (nombre.isEmpty() || contrasena.isEmpty()) {
                    JOptionPane.showMessageDialog(RegistroUsuario.this, "El nombre y la contraseña son obligatorios.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    return; // Detiene la ejecución aquí
                }

                // 2. Cargar usuarios existentes
                ArrayList<Usuario> usuarios = GestorUsuarios.cargarUsuarios();

                // 3. Crear nuevo usuario (el ID será el tamaño de la lista + 1)
                int nuevoId = usuarios.size() + 1;
                Usuario nuevoUsuario = new Usuario(nuevoId, nombre, email, contrasena, telefono, direccion);

                // 4. Añadir a la lista y guardar
                usuarios.add(nuevoUsuario);
                GestorUsuarios.guardarUsuarios(usuarios);

                JOptionPane.showMessageDialog(RegistroUsuario.this, "Usuario registrado correctamente.");
                dispose(); // Cerrar la ventana de registro
            }
        });

        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Solo cerrar la ventana
            }
        });
    }
}
