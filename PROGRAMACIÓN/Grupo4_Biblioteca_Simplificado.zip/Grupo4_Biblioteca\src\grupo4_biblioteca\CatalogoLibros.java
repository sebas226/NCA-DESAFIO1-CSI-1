package grupo4_biblioteca;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;

public class CatalogoLibros extends JFrame {
    private ArrayList<Libro> catalogoGeneral;
    private ArrayList<Libro> librosElegidos;
    private Usuario usuarioActual;

    private JTable tablaCatalogo;
    private JTable tablaElegidos;
    private DefaultTableModel modeloCatalogo;
    private DefaultTableModel modeloElegidos;

    private final String ARCHIVO_CATALOGO = "catalogo.dat";

    public CatalogoLibros(Usuario usuario) {
        this.usuarioActual = usuario;
        this.catalogoGeneral = new ArrayList<>();
        this.librosElegidos = new ArrayList<>();

        setTitle("Catálogo de Libros - Usuario: " + usuario.getNombreUsuario());
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        cargarCatalogo(); // Carga de archivo si existe o datos falsos
        initComponents();
        actualizarTablaCatalogo();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // --- Modelos de Tablas ---
        String[] colCatalogo = {"ID", "Título", "Género", "Cant. Disp.", "Tipo"};
        modeloCatalogo = new DefaultTableModel(colCatalogo, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaCatalogo = new JTable(modeloCatalogo);

        String[] colElegidos = {"ID", "Título", "Tipo"};
        modeloElegidos = new DefaultTableModel(colElegidos, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaElegidos = new JTable(modeloElegidos);

        // --- Paneles de Contenido ---
        JPanel panelCentral = new JPanel(new GridLayout(1, 2, 10, 10));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Catalogo Disponible
        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        panelIzquierdo.setBorder(BorderFactory.createTitledBorder("Catálogo Disponible"));
        panelIzquierdo.add(new JScrollPane(tablaCatalogo), BorderLayout.CENTER);
        JButton btnElegir = new JButton("Añadir a mi préstamo ->");
        panelIzquierdo.add(btnElegir, BorderLayout.SOUTH);

        // Mis libros prestados/elegidos
        JPanel panelDerecho = new JPanel(new BorderLayout());
        panelDerecho.setBorder(BorderFactory.createTitledBorder("Mis Libros Elegidos"));
        panelDerecho.add(new JScrollPane(tablaElegidos), BorderLayout.CENTER);

        panelCentral.add(panelIzquierdo);
        panelCentral.add(panelDerecho);
        add(panelCentral, BorderLayout.CENTER);

        // --- Panel de Guardado en Archivos ---
        JPanel panelSuperior = new JPanel();
        JButton btnGuardar = new JButton("Guardar Catálogo (ObjectOutputStream)");
        JButton btnCargar = new JButton("Recargar Catálogo (ObjectInputStream)");
        panelSuperior.add(btnGuardar);
        panelSuperior.add(btnCargar);
        add(panelSuperior, BorderLayout.NORTH);

        // --- Eventos ---
        btnElegir.addActionListener((ActionEvent e) -> {
            int fila = tablaCatalogo.getSelectedRow();
            if (fila != -1) {
                Libro libroSelec = catalogoGeneral.get(fila);
                if (libroSelec.getCantidadDisponible() > 0) {
                    libroSelec.setCantidadDisponible(libroSelec.getCantidadDisponible() - 1);
                    librosElegidos.add(libroSelec);
                    actualizarTablaCatalogo();
                    actualizarTablaElegidos();
                } else {
                    JOptionPane.showMessageDialog(this, "No hay copias disponibles en este momento.", "Sin stock", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un libro del catálogo primero.");
            }
        });

        btnGuardar.addActionListener(e -> guardarCatalogo());
        btnCargar.addActionListener(e -> {
            cargarCatalogo();
            actualizarTablaCatalogo();
        });
    }

    private void actualizarTablaCatalogo() {
        modeloCatalogo.setRowCount(0);
        for (Libro l : catalogoGeneral) {
            modeloCatalogo.addRow(new Object[]{
                l.getIdLibro(), l.getTitulo(), l.getGenero(), l.getCantidadDisponible(), l.obtenerTipoLibro()
            });
        }
    }

    private void actualizarTablaElegidos() {
        modeloElegidos.setRowCount(0);
        for (Libro l : librosElegidos) {
            modeloElegidos.addRow(new Object[]{
                l.getIdLibro(), l.getTitulo(), l.obtenerTipoLibro()
            });
        }
    }

    private void guardarCatalogo() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_CATALOGO))) {
            oos.writeObject(catalogoGeneral);
            JOptionPane.showMessageDialog(this, "Catálogo guardado con éxito en el archivo.");
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar el archivo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    private void cargarCatalogo() {
        File archivo = new File(ARCHIVO_CATALOGO);
        if (archivo.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_CATALOGO))) {
                catalogoGeneral = (ArrayList<Libro>) ois.readObject();
                if (modeloCatalogo != null) {
                    JOptionPane.showMessageDialog(this, "Datos cargados desde " + ARCHIVO_CATALOGO);
                }
            } catch (IOException | ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        } else {
            // Inicializar con datos de prueba si no hay archivo (Simulamos una carga inicial)
            catalogoGeneral.clear();
            catalogoGeneral.add(new LibroFisico(1, "Cien años de soledad", "Novela", 10, 10, 1, "A1", "Disponible"));
            catalogoGeneral.add(new LibroDigital(2, "Harry Potter 1", "Fantasía", 15, 15, 2, "EPUB", 3000, "http://libros.com/2.epub"));
            catalogoGeneral.add(new LibroFisico(3, "It", "Terror", 8, 8, 3, "B1", "No Disponible"));
            catalogoGeneral.add(new LibroDigital(4, "Orient Express", "Policial", 12, 12, 4, "EPUB", 4500, "http://libros.com/4.epub"));
            catalogoGeneral.add(new LibroDigital(5, "1984", "Distopía", 20, 20, 5, "PDF", 8000, "http://libros.com/5.pdf"));
            
            // Si el método se llama mediante botón, actualizamos aviso
            if (modeloCatalogo != null) {
                JOptionPane.showMessageDialog(this, "No se encontró un archivo previo. Se han cargado datos iniciales por defecto.");
            }
        }
    }
}
