package grupo4_biblioteca;

import java.io.Serializable;

public abstract class Libro implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int idLibro;
    private String titulo;
    private String genero;
    private int cantidadTotal;
    private int cantidadDisponible;
    private int idAutor;

    public Libro(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor) {
        this.idLibro = idLibro;
        this.titulo = titulo;
        this.genero = genero;
        this.cantidadTotal = cantidadTotal;
        this.cantidadDisponible = cantidadDisponible;
        this.idAutor = idAutor;
    }

    // Getters y Setters
    public int getIdLibro() { return idLibro; }
    public void setIdLibro(int idLibro) { this.idLibro = idLibro; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public int getCantidadTotal() { return cantidadTotal; }
    public void setCantidadTotal(int cantidadTotal) { this.cantidadTotal = cantidadTotal; }

    public int getCantidadDisponible() { return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) { this.cantidadDisponible = cantidadDisponible; }

    public int getIdAutor() { return idAutor; }
    public void setIdAutor(int idAutor) { this.idAutor = idAutor; }
    
    // Método abstracto (opcional) para dar comportamientos específicos
    public abstract String obtenerTipoLibro();
}
