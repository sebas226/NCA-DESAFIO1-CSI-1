package grupo4_biblioteca;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
/**
 * Clase principal que arranca la aplicación.
 */

public class Grupo4_Biblioteca extends Application{

   
    public void start(Stage primaryStage) {
        PantallaPrincipal ObjetoPrincipal = new PantallaPrincipal();
        ObjetoPrincipal.setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
