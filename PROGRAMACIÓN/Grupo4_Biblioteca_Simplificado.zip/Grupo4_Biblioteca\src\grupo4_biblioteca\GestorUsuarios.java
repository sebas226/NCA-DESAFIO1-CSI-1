package grupo4_biblioteca;

import java.io.*;
import java.util.ArrayList;

/**
 * Clase para gestionar la carga y guardado de usuarios en un archivo.
 * Simplificada para que sea fácil de entender.
 */
public class GestorUsuarios {
    private static final String ARCHIVO_USUARIOS = "usuarios.dat";

    /**
     * Carga la lista de usuarios desde el archivo.
     * Si no existe o hay un error, devuelve una lista nueva con un usuario por defecto.
     */
    public static ArrayList<Usuario> cargarUsuarios() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        File archivo = new File(ARCHIVO_USUARIOS);

        if (archivo.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_USUARIOS))) {
                usuarios = (ArrayList<Usuario>) ois.readObject();
            } catch (Exception ex) {
                System.out.println("Error al cargar usuarios: " + ex.getMessage());
            }
        } else {
            // Usuario por defecto si no hay archivo
            Usuario admin = new Usuario(1, "juan123", "juan@email.com", "1234", "666111222", "Calle A");
            usuarios.add(admin);
            guardarUsuarios(usuarios); // Creamos el archivo por primera vez
        }
        
        return usuarios;
    }

    /**
     * Guarda la lista de usuarios en el archivo.
     */
    public static void guardarUsuarios(ArrayList<Usuario> usuarios) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_USUARIOS))) {
            oos.writeObject(usuarios);
        } catch (IOException ex) {
            System.out.println("Error al guardar usuarios: " + ex.getMessage());
        }
    }
}
