package grupo4_biblioteca;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Pantalla Principal de la Aplicación (Login).
 * Simplificada para ser fácil de entender en 1º DAM.
 */
public class PantallaPrincipal extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnAcceder;
    private JButton btnRegistrar;

    public PantallaPrincipal() {
        // Configuración de la ventana principal
        setTitle("Biblioteca - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Al cerrar la ventana se termina el programa
        setResizable(false);

        // Usamos AbsoluteLayout para colocar los elementos exactamente sobre la imagen
        JPanel panelFondo = new JPanel();
        panelFondo.setLayout(null);
        panelFondo.setPreferredSize(new Dimension(932, 600)); // Ajusta al tamaño de la imagen

        // --- CREAR ELEMENTOS DE LA INTERFAZ ---

        // Etiqueta Usuario
        JLabel lblUsuario = new JLabel("USUARIO");
        lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setBounds(420, 220, 100, 30); // x, y, ancho, alto
        panelFondo.add(lblUsuario);

        // Campo de Texto Usuario
        txtUsuario = new JTextField();
        txtUsuario.setBounds(360, 250, 200, 30);
        panelFondo.add(txtUsuario);

        // Etiqueta Contraseña
        JLabel lblContrasena = new JLabel("CONTRASEÑA");
        lblContrasena.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblContrasena.setForeground(Color.WHITE);
        lblContrasena.setBounds(400, 290, 150, 30);
        panelFondo.add(lblContrasena);

        // Campo de Texto Contraseña
        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(360, 320, 200, 30);
        panelFondo.add(txtContrasena);

        // Botón Acceder
        btnAcceder = new JButton("Acceder");
        btnAcceder.setBounds(360, 380, 95, 35);
        panelFondo.add(btnAcceder);

        // Botón Registrar
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(465, 380, 95, 35);
        panelFondo.add(btnRegistrar);

        // --- IMAGEN DE FONDO (Debe añadirse lo ÚLTIMO para que quede detrás) ---
        JLabel lblFondo = new JLabel();
        try {
            // Intenta cargar la imagen desde los recursos
            lblFondo.setIcon(new ImageIcon(getClass().getResource("/grupo4_biblioteca/KoalaLogin.png")));
        } catch (Exception e) {
            System.out.println("No se encontró la imagen KoalaLogin.png");
        }
        lblFondo.setBounds(0, 0, 932, 600);
        panelFondo.add(lblFondo);

        // Añadimos el panel a la ventana
        add(panelFondo);
        pack(); // Ajusta el tamaño de la ventana al preferido del panel
        setLocationRelativeTo(null); // Centrar en la pantalla

        // --- ACCIONES DE LOS BOTONES ---

        // Acción del botón Acceder
        btnAcceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuarioIngresado = txtUsuario.getText();
                String contrasenaIngresada = new String(txtContrasena.getPassword());

                // Cargar lista de usuarios guardada
                ArrayList<Usuario> usuarios = GestorUsuarios.cargarUsuarios();
                Usuario usuarioEncontrado = null;

                // Buscar si el usuario y contraseña coinciden
                for (Usuario u : usuarios) {
                    if (u.getNombreUsuario().equals(usuarioIngresado) && u.getContrasena().equals(contrasenaIngresada)) {
                        usuarioEncontrado = u;
                        break;
                    }
                }

                if (usuarioEncontrado != null) {
                    // Login correcto
                    JOptionPane.showMessageDialog(PantallaPrincipal.this, "¡Bienvenido, " + usuarioEncontrado.getNombreUsuario() + "!");
                    
                    // Abrir catálogo
                    CatalogoLibros catalogo = new CatalogoLibros(usuarioEncontrado);
                    catalogo.setVisible(true);
                    
                    // Ocultar pantalla de login
                    dispose();
                } else {
                    // Login incorrecto
                    JOptionPane.showMessageDialog(PantallaPrincipal.this, "Usuario o contraseña incorrectos.", "Error de Acceso", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Acción del botón Registrar
        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abrir la ventana de registro
                RegistroUsuario registro = new RegistroUsuario(PantallaPrincipal.this);
                registro.setVisible(true);
            }
        });
    }
}
