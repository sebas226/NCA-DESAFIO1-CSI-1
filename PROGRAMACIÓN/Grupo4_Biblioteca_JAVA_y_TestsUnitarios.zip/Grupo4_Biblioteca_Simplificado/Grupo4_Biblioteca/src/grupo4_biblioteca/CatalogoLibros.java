package grupo4_biblioteca;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Ventana donde se ven los libros disponibles y los libros prestados.
 */
public class CatalogoLibros extends JFrame {

    // Consulta para sacar todos los libros del catálogo.
    private static final String CONSULTA_CATALOGO =
        "SELECT l.*, lf.ubicacion, lf.estado, ld.formato, ld.tamaño_archivo, ld.enlace_descarga " +
        "FROM Libro l " +
        "LEFT JOIN libro_fisico lf ON l.id_libro = lf.id_libro " +
        "LEFT JOIN libro_digital ld ON l.id_libro = ld.id_libro";

    // Consulta para sacar solo los libros prestados del usuario que ha entrado.
    private static final String CONSULTA_MIS_LIBROS =
        "SELECT l.*, lf.ubicacion, lf.estado, ld.formato, ld.tamaño_archivo, ld.enlace_descarga " +
        "FROM Prestamo p " +
        "JOIN Libro l ON p.id_libro = l.id_libro " +
        "LEFT JOIN libro_fisico lf ON l.id_libro = lf.id_libro " +
        "LEFT JOIN libro_digital ld ON l.id_libro = ld.id_libro " +
        "WHERE p.id_usuario = ?";

    // Lista con todos los libros que salen en la tabla de la izquierda.
    private ArrayList<Libro> listaCatalogo;

    // Lista con los libros que ya tiene prestados el usuario.
    private ArrayList<Libro> listaMisLibros;

    // Usuario que ha iniciado sesión.
    private Usuario usuarioActual;

    // Tablas que se ven en pantalla.
    private JTable tablaCatalogo;
    private JTable tablaMisLibros;

    // Modelos: aquí se guardan las filas que muestran las tablas.
    private DefaultTableModel modeloCatalogo;
    private DefaultTableModel modeloMisLibros;

    public CatalogoLibros(Usuario usuario) {
        // Guardamos el usuario y creamos las listas vacías.
        this.usuarioActual = usuario;
        this.listaCatalogo = new ArrayList<>();
        this.listaMisLibros = new ArrayList<>();

        // Preparamos la ventana.
        setTitle("Catálogo de Libros - Usuario: " + usuario.getNombreUsuario());
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Primero cargamos los datos y después montamos la pantalla.
        cargarCatalogo();
        cargarMisLibros();
        montarPantalla();
        rellenarTablaCatalogo();
        rellenarTablaMisLibros();
    }

    private void montarPantalla() {
        // BorderLayout permite colocar cosas arriba, abajo, centro, etc.
        setLayout(new BorderLayout(10, 10));

        // Creamos las dos tablas.
        modeloCatalogo = hacerModeloTabla(new String[]{"ID", "Título", "Género", "Cant. Disp.", "Tipo"});
        tablaCatalogo = new JTable(modeloCatalogo);

        modeloMisLibros = hacerModeloTabla(new String[]{"ID", "Título", "Tipo"});
        tablaMisLibros = new JTable(modeloMisLibros);

        // Panel central con las dos tablas una al lado de la otra.
        JPanel panelCentral = new JPanel(new GridLayout(1, 2, 10, 10));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Botón para añadir un libro al préstamo.
        JButton botonElegirLibro = new JButton("Añadir a mi préstamo ->");

        // Creamos los dos paneles con sus tablas.
        JPanel panelCatalogo = hacerPanelConTabla("Catálogo Disponible", tablaCatalogo, botonElegirLibro);
        JPanel panelMisLibros = hacerPanelConTabla("Mis Libros Prestados", tablaMisLibros, null);

        panelCentral.add(panelCatalogo);
        panelCentral.add(panelMisLibros);
        add(panelCentral, BorderLayout.CENTER);

        // Panel de arriba con el botón de cerrar sesión.
        JPanel panelArriba = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton botonCerrarSesion = new JButton("Cerrar Sesión");
        panelArriba.add(botonCerrarSesion);
        add(panelArriba, BorderLayout.NORTH);

        // Acciones de los botones.
        botonCerrarSesion.addActionListener(e -> volverAlLogin());
        botonElegirLibro.addActionListener(e -> cogerLibroSeleccionado());
    }

    private DefaultTableModel hacerModeloTabla(String[] columnas) {
        // Este modelo hace que las celdas no se puedan editar.
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
    }

    private JPanel hacerPanelConTabla(String titulo, JTable tabla, JButton botonAbajo) {
        // Panel con título, tabla en el centro y a veces un botón abajo.
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(titulo));
        panel.add(new JScrollPane(tabla), BorderLayout.CENTER);

        if (botonAbajo != null) {
            panel.add(botonAbajo, BorderLayout.SOUTH);
        }

        return panel;
    }

    private void volverAlLogin() {
        // Preguntamos antes de cerrar la sesión.
        int respuesta = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que deseas cerrar sesión?",
            "Cerrar Sesión",
            JOptionPane.YES_NO_OPTION
        );

        // Si dice que sí, abrimos otra vez el login.
        if (respuesta == JOptionPane.YES_OPTION) {
            PantallaPrincipal login = new PantallaPrincipal();
            login.setVisible(true);
            dispose();
        }
    }

    private void cogerLibroSeleccionado() {
        // Miramos qué fila está seleccionada en la tabla del catálogo.
        int fila = tablaCatalogo.getSelectedRow();

        // Si no hay fila seleccionada, avisamos.
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un libro del catálogo primero.");
            return;
        }

        // Como la lista y la tabla tienen el mismo orden, usamos el número de fila.
        Libro libroElegido = listaCatalogo.get(fila);

        // Solo se puede prestar si quedan copias disponibles.
        if (libroElegido.getCantidadDisponible() > 0) {
            meterLibroEnPrestamo(libroElegido);
        } else {
            JOptionPane.showMessageDialog(this, "No hay copias disponibles en este momento.", "Sin stock", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void rellenarTablaCatalogo() {
        // Borramos las filas anteriores para no duplicar datos.
        modeloCatalogo.setRowCount(0);

        // Añadimos una fila por cada libro del catálogo.
        for (Libro libro : listaCatalogo) {
            modeloCatalogo.addRow(new Object[]{
                libro.getIdLibro(),
                libro.getTitulo(),
                libro.getGenero(),
                libro.getCantidadDisponible(),
                libro.obtenerTipoLibro()
            });
        }
    }

    private void rellenarTablaMisLibros() {
        // Borramos las filas anteriores para no duplicar datos.
        modeloMisLibros.setRowCount(0);

        // Añadimos una fila por cada libro prestado.
        for (Libro libro : listaMisLibros) {
            modeloMisLibros.addRow(new Object[]{
                libro.getIdLibro(),
                libro.getTitulo(),
                libro.obtenerTipoLibro()
            });
        }
    }

    private void cargarCatalogo() {
        // Limpiamos la lista antes de meter libros nuevos.
        listaCatalogo.clear();

        try (Connection conexion = dbConnection.conectar();
             PreparedStatement consulta = conexion.prepareStatement(CONSULTA_CATALOGO);
             ResultSet resultado = consulta.executeQuery()) {
            
            // Recorremos todos los libros que devuelve la base de datos.
            while (resultado.next()) {
                // Un libro puede estar en la tabla de físicos, en la de digitales o en las dos.
                if (resultado.getString("ubicacion") != null) {
                    listaCatalogo.add(hacerLibroFisico(resultado));
                } 
                
                if (resultado.getString("formato") != null) {
                    listaCatalogo.add(hacerLibroDigital(resultado));
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar catálogo desde MySQL: " + ex.getMessage());
        }
    }

    private void cargarMisLibros() {
        // Limpiamos la lista de préstamos antes de volver a cargarla.
        listaMisLibros.clear();
                     
        try (Connection conexion = dbConnection.conectar();
             PreparedStatement consulta = conexion.prepareStatement(CONSULTA_MIS_LIBROS)) {

            // El interrogante de la consulta se cambia por el id del usuario.
            consulta.setInt(1, usuarioActual.getIdUsuario());

            try (ResultSet resultado = consulta.executeQuery()) {
                // Recorremos los libros que tiene prestados este usuario.
                while (resultado.next()) {
                    if (resultado.getString("ubicacion") != null) {
                        listaMisLibros.add(hacerLibroFisico(resultado));
                    } else if (resultado.getString("formato") != null) {
                        listaMisLibros.add(hacerLibroDigital(resultado));
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar préstamos: " + ex.getMessage());
        }
    }

    private LibroFisico hacerLibroFisico(ResultSet resultado) throws SQLException {
        // Creamos un objeto LibroFisico usando los datos de la fila actual.
        return new LibroFisico(
            resultado.getInt("id_libro"),
            resultado.getString("titulo"),
            resultado.getString("genero"),
            resultado.getInt("cantidad_total"),
            resultado.getInt("cantidad_disponible"),
            resultado.getInt("id_autor"),
            resultado.getString("ubicacion"),
            resultado.getString("estado")
        );
    }

    private LibroDigital hacerLibroDigital(ResultSet resultado) throws SQLException {
        // Creamos un objeto LibroDigital usando los datos de la fila actual.
        return new LibroDigital(
            resultado.getInt("id_libro"),
            resultado.getString("titulo"),
            resultado.getString("genero"),
            resultado.getInt("cantidad_total"),
            resultado.getInt("cantidad_disponible"),
            resultado.getInt("id_autor"),
            resultado.getString("formato"),
            resultado.getInt("tamaño_archivo"),
            resultado.getString("enlace_descarga")
        );
    }

    private void meterLibroEnPrestamo(Libro libroElegido) {
        // Una consulta añade el préstamo y la otra resta una copia disponible.
        String consultaInsertar = "INSERT INTO Prestamo (id_usuario, id_libro) VALUES (?, ?)";
        String consultaRestar = "UPDATE Libro SET cantidad_disponible = cantidad_disponible - 1 WHERE id_libro = ?";
        
        try (Connection conexion = dbConnection.conectar()) {
            // Desactivamos el autocommit para hacer las dos consultas juntas.
            conexion.setAutoCommit(false);

            try (PreparedStatement insertar = conexion.prepareStatement(consultaInsertar);
                 PreparedStatement restar = conexion.prepareStatement(consultaRestar)) {

                 // Guardamos el préstamo en la tabla Prestamo.
                 insertar.setInt(1, usuarioActual.getIdUsuario());
                 insertar.setInt(2, libroElegido.getIdLibro());
                 insertar.executeUpdate();

                 // Restamos una unidad al libro prestado.
                 restar.setInt(1, libroElegido.getIdLibro());
                 restar.executeUpdate();

                 // Si todo ha ido bien, confirmamos los cambios.
                 conexion.commit();

                 // Actualizamos también las listas para que la pantalla cambie al momento.
                 libroElegido.setCantidadDisponible(libroElegido.getCantidadDisponible() - 1);
                 listaMisLibros.add(libroElegido);

                 // Volvemos a pintar las tablas.
                 rellenarTablaCatalogo();
                 rellenarTablaMisLibros();

                 JOptionPane.showMessageDialog(this, "Libro prestado correctamente.");
            } catch (SQLException ex) {
                 // Si falla algo, deshacemos los cambios.
                 conexion.rollback();
                 JOptionPane.showMessageDialog(this, "Error al registrar el préstamo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println("Error de conexión: " + ex.getMessage());
        }
    }
}
