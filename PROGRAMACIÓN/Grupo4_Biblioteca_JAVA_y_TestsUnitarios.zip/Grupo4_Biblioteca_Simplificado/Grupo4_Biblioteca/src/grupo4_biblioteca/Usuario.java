package grupo4_biblioteca;

import java.io.Serializable;

/**
 * Esta clase guarda los datos de una persona registrada en la biblioteca.
 */
public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    
    // Datos del usuario.
    private int idUsuario;
    private String nombreUsuario;
    private String email;
    private String contrasena;
    private String telefono;
    private String direccion;

    public Usuario(int idUsuario, String nombreUsuario, String email, String contrasena, String telefono, String direccion) {
        // Guardamos en el objeto los datos que llegan al constructor.
        this.idUsuario = idUsuario;
        this.nombreUsuario = nombreUsuario;
        this.email = email;
        this.contrasena = contrasena;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    // Devuelve el id del usuario.
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    // Devuelve el nombre de usuario.
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    // Devuelve el email.
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    // Devuelve la contraseña.
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    // Devuelve el teléfono.
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    // Devuelve la dirección.
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
}
