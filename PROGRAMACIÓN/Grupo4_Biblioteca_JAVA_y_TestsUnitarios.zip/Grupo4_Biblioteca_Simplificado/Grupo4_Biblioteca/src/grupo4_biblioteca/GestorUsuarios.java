package grupo4_biblioteca;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Esta clase se encarga de trabajar con los usuarios en la base de datos.
 */
public class GestorUsuarios {

    public static Usuario validarUsuario(String nombre, String contrasena) {
        // Esta consulta busca un usuario con ese nombre y esa contraseña.
        String consultaSql = "SELECT * FROM Usuario WHERE nombre_usuario = ? AND contraseña = ?";
        
        try (Connection conexion = dbConnection.conectar();
             PreparedStatement consulta = conexion.prepareStatement(consultaSql)) {
            
            // Cambiamos los interrogantes de la consulta por los datos escritos.
            consulta.setString(1, nombre);
            consulta.setString(2, contrasena);

            // Ejecutamos la consulta y guardamos el resultado.
            ResultSet resultado = consulta.executeQuery();
            
            // Si hay una fila, el usuario existe.
            if (resultado.next()) {
                return hacerUsuario(resultado);
            }
        } catch (SQLException ex) {
            System.out.println("Error al validar usuario: " + ex.getMessage());
        }
        
        // Si no se ha encontrado nada, devolvemos null.
        return null;
    }

    public static boolean registrarUsuario(Usuario usuario) {
        // Esta consulta añade un usuario nuevo.
        String consultaSql = "INSERT INTO Usuario (nombre_usuario, email, contraseña, telefono, direccion) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conexion = dbConnection.conectar();
             PreparedStatement consulta = conexion.prepareStatement(consultaSql)) {
            
            // Rellenamos los datos del INSERT.
            consulta.setString(1, usuario.getNombreUsuario());
            consulta.setString(2, usuario.getEmail());
            consulta.setString(3, usuario.getContrasena());
            consulta.setString(4, usuario.getTelefono());
            consulta.setString(5, usuario.getDireccion());
            
            // Si se inserta al menos una fila, el registro ha salido bien.
            int filasInsertadas = consulta.executeUpdate();
            return filasInsertadas > 0;
        } catch (SQLException ex) {
            System.out.println("Error al registrar usuario: " + ex.getMessage());
        }
        
        // Si hay error, indicamos que no se ha guardado.
        return false;
    }

    private static Usuario hacerUsuario(ResultSet resultado) throws SQLException {
        // Convertimos la fila de la base de datos en un objeto Usuario.
        return new Usuario(
            resultado.getInt("id_usuario"),
            resultado.getString("nombre_usuario"),
            resultado.getString("email"),
            resultado.getString("contraseña"),
            resultado.getString("telefono"),
            resultado.getString("direccion")
        );
    }
}
