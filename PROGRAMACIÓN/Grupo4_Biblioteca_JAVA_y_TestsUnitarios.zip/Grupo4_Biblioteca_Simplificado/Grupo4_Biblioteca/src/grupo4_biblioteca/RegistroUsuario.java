package grupo4_biblioteca;

import javax.swing.*;
import java.awt.*;

/**
 * Esta ventana sirve para crear un usuario nuevo.
 */
public class RegistroUsuario extends JDialog {

    // Cajas donde se escriben los datos del usuario.
    private JTextField cajaNombre;
    private JTextField cajaEmail;
    private JPasswordField cajaContrasena;
    private JTextField cajaTelefono;
    private JTextField cajaDireccion;

    // Botones de la ventana.
    private JButton botonGuardar;
    private JButton botonCancelar;

    public RegistroUsuario(JFrame ventanaAnterior) {
        // El true hace que esta ventana bloquee la de atrás hasta que se cierre.
        super(ventanaAnterior, "Registro de Nuevo Usuario", true);

        // Tamaño y configuración básica.
        setSize(350, 400);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(ventanaAnterior);

        // Creamos el formulario y lo añadimos a la ventana.
        JPanel panel = hacerFormulario();
        add(panel);

        // Acciones de los botones.
        botonGuardar.addActionListener(e -> guardarDatos());
        botonCancelar.addActionListener(e -> dispose());
    }

    private JPanel hacerFormulario() {
        // GridLayout coloca los elementos en filas y columnas.
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Nombre de usuario.
        panel.add(new JLabel("Nombre de Usuario:"));
        cajaNombre = new JTextField();
        panel.add(cajaNombre);

        // Email.
        panel.add(new JLabel("Email:"));
        cajaEmail = new JTextField();
        panel.add(cajaEmail);

        // Contraseña.
        panel.add(new JLabel("Contraseña:"));
        cajaContrasena = new JPasswordField();
        panel.add(cajaContrasena);

        // Teléfono.
        panel.add(new JLabel("Teléfono:"));
        cajaTelefono = new JTextField();
        panel.add(cajaTelefono);

        // Dirección.
        panel.add(new JLabel("Dirección:"));
        cajaDireccion = new JTextField();
        panel.add(cajaDireccion);

        // Botones finales.
        botonGuardar = new JButton("Guardar");
        botonCancelar = new JButton("Cancelar");
        panel.add(botonGuardar);
        panel.add(botonCancelar);

        return panel;
    }

    private void guardarDatos() {
        // Guardamos en variables lo que ha escrito el usuario.
        String nombre = cajaNombre.getText();
        String email = cajaEmail.getText();
        String contrasena = new String(cajaContrasena.getPassword());
        String telefono = cajaTelefono.getText();
        String direccion = cajaDireccion.getText();

        // Comprobamos que los campos obligatorios no estén vacíos.
        if (nombre.isEmpty() || contrasena.isEmpty() || telefono.isEmpty() || direccion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor rellena los campos obligatorios.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Creamos el usuario con los datos escritos.
        Usuario nuevoUsuario = new Usuario(0, nombre, email, contrasena, telefono, direccion);

        // Intentamos guardarlo en la base de datos.
        boolean seHaGuardado = GestorUsuarios.registrarUsuario(nuevoUsuario);

        if (seHaGuardado) {
            JOptionPane.showMessageDialog(this, "Usuario registrado correctamente.");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
