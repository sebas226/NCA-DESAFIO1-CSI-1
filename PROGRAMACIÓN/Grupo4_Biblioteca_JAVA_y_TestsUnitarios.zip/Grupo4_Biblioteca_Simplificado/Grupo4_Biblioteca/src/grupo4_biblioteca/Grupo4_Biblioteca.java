package grupo4_biblioteca;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Clase principal. Desde aquí empieza el programa.
 */
public class Grupo4_Biblioteca extends Application {

    @Override
    public void start(Stage ventanaJavaFx) {
        // Creamos la pantalla de login.
        PantallaPrincipal pantallaLogin = new PantallaPrincipal();

        // Hacemos visible la pantalla.
        pantallaLogin.setVisible(true);
    }

    public static void main(String[] args) {
        // Java llama a start() después de este launch.
        launch(args);
    }
}
