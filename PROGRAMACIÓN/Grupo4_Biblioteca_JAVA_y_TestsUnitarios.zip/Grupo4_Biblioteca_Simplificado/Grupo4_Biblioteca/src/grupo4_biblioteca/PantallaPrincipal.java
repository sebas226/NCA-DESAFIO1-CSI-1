package grupo4_biblioteca;

import javax.swing.*;
import java.awt.*;

/**
 * Esta es la primera ventana que se ve al abrir el programa.
 * Sirve para entrar con usuario y contraseña o para abrir el registro.
 */
public class PantallaPrincipal extends JFrame {

    // Campos donde el usuario escribe sus datos.
    private JTextField cajaUsuario;
    private JPasswordField cajaContrasena;

    // Botones de la pantalla principal.
    private JButton botonEntrar;
    private JButton botonRegistro;

    public PantallaPrincipal() {
        // Primero preparamos la ventana.
        prepararVentana();

        // Creamos el panel donde van todos los componentes.
        JPanel panelFondo = hacerPanelFondo();

        // Añadimos los textos, cajas, botones y la imagen.
        ponerCajasDeTexto(panelFondo);
        ponerBotones(panelFondo);
        ponerImagen(panelFondo);

        // Metemos el panel en la ventana y la centramos.
        add(panelFondo);
        pack();
        setLocationRelativeTo(null);

        // Indicamos qué pasa cuando se pulsa cada botón.
        botonEntrar.addActionListener(e -> mirarLogin());
        botonRegistro.addActionListener(e -> abrirVentanaRegistro());
    }

    private void prepararVentana() {
        // Título y comportamiento básico de la ventana.
        setTitle("Biblioteca - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
    }

    private JPanel hacerPanelFondo() {
        // Usamos posiciones fijas porque la imagen de fondo ya tiene un diseño concreto.
        JPanel panelFondo = new JPanel();
        panelFondo.setLayout(null);
        panelFondo.setPreferredSize(new Dimension(932, 600));
        return panelFondo;
    }

    private void ponerCajasDeTexto(JPanel panelFondo) {
        // Texto que indica dónde escribir el usuario.
        JLabel textoUsuario = new JLabel("USUARIO");
        textoUsuario.setFont(new Font("Segoe UI", Font.BOLD, 18));
        textoUsuario.setForeground(Color.WHITE);
        textoUsuario.setBounds(420, 220, 100, 30);
        panelFondo.add(textoUsuario);

        // Caja para escribir el nombre de usuario.
        cajaUsuario = new JTextField();
        cajaUsuario.setBounds(360, 250, 200, 30);
        panelFondo.add(cajaUsuario);

        // Texto que indica dónde escribir la contraseña.
        JLabel textoContrasena = new JLabel("CONTRASEÑA");
        textoContrasena.setFont(new Font("Segoe UI", Font.BOLD, 18));
        textoContrasena.setForeground(Color.WHITE);
        textoContrasena.setBounds(400, 290, 150, 30);
        panelFondo.add(textoContrasena);

        // Caja para escribir la contraseña. No muestra las letras por seguridad.
        cajaContrasena = new JPasswordField();
        cajaContrasena.setBounds(360, 320, 200, 30);
        panelFondo.add(cajaContrasena);
    }

    private void ponerBotones(JPanel panelFondo) {
        // Botón para intentar entrar en la aplicación.
        botonEntrar = new JButton("Acceder");
        botonEntrar.setBounds(360, 380, 95, 35);
        panelFondo.add(botonEntrar);

        // Botón para abrir la ventana de registro.
        botonRegistro = new JButton("Registrar");
        botonRegistro.setBounds(465, 380, 95, 35);
        panelFondo.add(botonRegistro);
    }

    private void ponerImagen(JPanel panelFondo) {
        // La imagen se añade al final para que quede detrás de los campos.
        JLabel imagenFondo = new JLabel();
        try {
            imagenFondo.setIcon(new ImageIcon(getClass().getResource("/grupo4_biblioteca/KoalaLogin.png")));
        } catch (Exception e) {
            System.out.println("No se encontró la imagen KoalaLogin.png");
        }

        imagenFondo.setBounds(0, 0, 932, 600);
        panelFondo.add(imagenFondo);
    }

    private void mirarLogin() {
        // Recogemos lo que se ha escrito en las cajas.
        String usuarioEscrito = cajaUsuario.getText();
        String contrasenaEscrita = new String(cajaContrasena.getPassword());

        // Preguntamos a la base de datos si existe ese usuario.
        Usuario usuarioEncontrado = GestorUsuarios.validarUsuario(usuarioEscrito, contrasenaEscrita);

        // Si no existe, avisamos y salimos del método.
        if (usuarioEncontrado == null) {
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.", "Error de Acceso", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Si existe, damos la bienvenida y abrimos el catálogo.
        JOptionPane.showMessageDialog(this, "¡Bienvenido, " + usuarioEncontrado.getNombreUsuario() + "!");

        CatalogoLibros catalogo = new CatalogoLibros(usuarioEncontrado);
        catalogo.setVisible(true);

        // Cerramos la pantalla de login.
        dispose();
    }

    private void abrirVentanaRegistro() {
        // Abrimos la ventana de registro encima del login.
        RegistroUsuario registro = new RegistroUsuario(this);
        registro.setVisible(true);
    }
}
