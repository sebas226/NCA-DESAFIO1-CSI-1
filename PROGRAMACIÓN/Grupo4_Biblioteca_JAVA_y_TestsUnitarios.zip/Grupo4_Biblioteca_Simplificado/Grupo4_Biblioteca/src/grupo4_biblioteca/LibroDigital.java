package grupo4_biblioteca;

import java.io.Serializable;

/**
 * Esta clase representa un libro que está en formato digital.
 */
public class LibroDigital extends Libro implements Serializable {
    private static final long serialVersionUID = 1L;
    
    // Formato del archivo, por ejemplo PDF o EPUB.
    private String formato;

    // Tamaño del archivo digital.
    private int tamanoArchivo;

    // Enlace para poder descargar o abrir el libro.
    private String enlaceDescarga;

    public LibroDigital(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor, String formato, int tamanoArchivo, String enlaceDescarga) {
        // Primero guardamos los datos comunes del libro.
        super(idLibro, titulo, genero, cantidadTotal, cantidadDisponible, idAutor);

        // Después guardamos los datos propios del libro digital.
        this.formato = formato;
        this.tamanoArchivo = tamanoArchivo;
        this.enlaceDescarga = enlaceDescarga;
    }

    // Devuelve el formato del archivo.
    public String getFormato() { return formato; }
    public void setFormato(String formato) { this.formato = formato; }

    // Devuelve el tamaño del archivo.
    public int getTamanoArchivo() { return tamanoArchivo; }
    public void setTamanoArchivo(int tamanoArchivo) { this.tamanoArchivo = tamanoArchivo; }

    // Devuelve el enlace de descarga.
    public String getEnlaceDescarga() { return enlaceDescarga; }
    public void setEnlaceDescarga(String enlaceDescarga) { this.enlaceDescarga = enlaceDescarga; }

    @Override
    public String obtenerTipoLibro() {
        // Este texto aparece en la tabla del catálogo.
        return "Digital";
    }
}
