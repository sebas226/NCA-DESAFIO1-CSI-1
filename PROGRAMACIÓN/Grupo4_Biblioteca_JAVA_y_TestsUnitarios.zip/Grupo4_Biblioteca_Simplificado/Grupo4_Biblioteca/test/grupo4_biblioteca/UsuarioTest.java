package grupo4_biblioteca;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas sencillas para comprobar que la clase Usuario guarda bien los datos.
 */
public class UsuarioTest {

    @Test
    public void comprobarQueElUsuarioSeCrea() {
        // Creamos un usuario normal.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Comprobamos que el objeto existe.
        assertNotNull(usuario);
    }

    @Test
    public void comprobarQueEsUnUsuario() {
        // Creamos un usuario normal.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Comprobamos que el objeto creado pertenece a la clase Usuario.
        assertTrue(usuario instanceof Usuario);
    }

    @Test
    public void comprobarDatosDelConstructor() {
        // Creamos un usuario con datos de prueba.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Comprobamos que los datos se han guardado bien.
        assertEquals(1, usuario.getIdUsuario());
        assertEquals("ana", usuario.getNombreUsuario());
        assertEquals("ana@gmail.com", usuario.getEmail());
        assertEquals("1234", usuario.getContrasena());
        assertEquals("600111222", usuario.getTelefono());
        assertEquals("Calle Luna", usuario.getDireccion());
    }

    @Test
    public void comprobarCambioDeNombre() {
        // Creamos un usuario.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Cambiamos el nombre de usuario.
        usuario.setNombreUsuario("laura");

        // Comprobamos que el cambio se ha hecho.
        assertEquals("laura", usuario.getNombreUsuario());
    }

    @Test
    public void comprobarCambioDeId() {
        // Creamos un usuario.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Cambiamos el id del usuario.
        usuario.setIdUsuario(5);

        // Comprobamos que el id nuevo se ha guardado.
        assertEquals(5, usuario.getIdUsuario());
    }

    @Test
    public void comprobarCambioDeEmail() {
        // Creamos un usuario.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Cambiamos el email.
        usuario.setEmail("nuevo@gmail.com");

        // Comprobamos que ahora tiene el email nuevo.
        assertEquals("nuevo@gmail.com", usuario.getEmail());
    }

    @Test
    public void comprobarCambioDeTelefonoYDireccion() {
        // Creamos un usuario.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Cambiamos teléfono y dirección.
        usuario.setTelefono("699888777");
        usuario.setDireccion("Calle Sol");

        // Comprobamos los cambios.
        assertEquals("699888777", usuario.getTelefono());
        assertEquals("Calle Sol", usuario.getDireccion());
    }

    @Test
    public void comprobarCambioDeContrasena() {
        // Creamos un usuario.
        Usuario usuario = new Usuario(1, "ana", "ana@gmail.com", "1234", "600111222", "Calle Luna");

        // Cambiamos la contraseña.
        usuario.setContrasena("abcd");

        // Comprobamos que se ha cambiado.
        assertEquals("abcd", usuario.getContrasena());
    }

    @Test
    public void comprobarUsuarioConIdCero() {
        // En el registro se crea el usuario con id 0 antes de guardarlo en la base de datos.
        Usuario usuario = new Usuario(0, "nuevo", "nuevo@gmail.com", "1111", "611222333", "Calle Nueva");

        // Comprobamos que se guarda ese id.
        assertEquals(0, usuario.getIdUsuario());
    }
}
