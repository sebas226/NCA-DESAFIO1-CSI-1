package grupo4_biblioteca;

/**
 * Aquí se guardan datos de la persona registrada
 */
public class Usuario {
    
    // datos usuario
    private int idUsuario;
    private String nombreUsuario;
    private String email;
    private String contrasena;
    private String telefono;
    private String direccion;

    public Usuario(int idUsuario, String nombreUsuario, String email, String contrasena, String telefono, String direccion) {
        // Guardamos datos recibidos con atributos del usuario
        this.idUsuario = idUsuario;
        setNombreUsuario(nombreUsuario);
        this.email = email;
        setContrasena(contrasena);
        this.telefono = telefono;
        this.direccion = direccion;
    }

    // deuelve id usuario
    public int getIdUsuario() { 
        return idUsuario; }
    public void setIdUsuario(int idUsuario) { 
        this.idUsuario = idUsuario; }

    // devueve nombre usuario
    public String getNombreUsuario() { 
        return nombreUsuario; }
    //una excepción por si se deja el campo vacío
    //el .trim() es para eliminar los espacios vacíos que hay al principio y al final de un texto
    public void setNombreUsuario(String nombreUsuario) {
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de usuario no puede estar vacío.");
        }
        this.nombreUsuario = nombreUsuario;
    }

    // devuelve email
    public String getEmail() { 
        return email; }
    public void setEmail(String email) { 
        this.email = email; }

    // devuelve contraseña
    public String getContrasena() { 
        return contrasena; }
    public void setContrasena(String contrasena) {
        //otra vez excepción y .trim() para eliminar espacios vacíos
        if (contrasena == null || contrasena.trim().isEmpty()) {
            throw new IllegalArgumentException("La contrasena no puede estar vacía.");
        }
        this.contrasena = contrasena;
    }

    // devuelve teléfono
    public String getTelefono() { 
        return telefono; }
    public void setTelefono(String telefono) { 
        this.telefono = telefono; }

    // devuelve dirección.
    public String getDireccion() { 
        return direccion; }
    public void setDireccion(String direccion) { 
        this.direccion = direccion; }
}
