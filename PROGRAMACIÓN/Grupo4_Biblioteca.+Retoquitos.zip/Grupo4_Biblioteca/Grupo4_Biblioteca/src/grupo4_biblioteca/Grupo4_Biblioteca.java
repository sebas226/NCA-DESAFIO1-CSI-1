package grupo4_biblioteca;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Clase principal
 * aquí inicia todo
 */
public class Grupo4_Biblioteca {

    public static void main(String[] args) {
        //es el método de abajo. para configurar el aspecto visual 
        configurarAspectoVentanas();

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                PantallaPrincipal pantallaLogin = new PantallaPrincipal();
                pantallaLogin.setVisible(true);
            }
        });
    }

    //Todo esto es opcional, sin ello el programa se ejecuta perfectamente, pero así todo tiene un mejor acabado
    //Sin esto, el programa se ejecuta con aspecto visual más antiguo
    private static void configurarAspectoVentanas() {
        UIManager.put("OptionPane.okButtonText", "Aceptar");
        UIManager.put("OptionPane.cancelButtonText", "Cancelar");
        UIManager.put("OptionPane.yesButtonText", "Sí");
        UIManager.put("OptionPane.noButtonText", "No");

        try {
            //Esto establece el aspecto visual del sistema operativo. 
            //Está puesto para que le de un aspecto distinto a la interfaz, más "profesional" se podría decir
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
            
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            System.out.println("No se pudo aplicar el aspecto visual del sistema: " + ex.getMessage());
        }

        UIManager.put("OptionPane.okButtonText", "Aceptar");
        UIManager.put("OptionPane.cancelButtonText", "Cancelar");
        UIManager.put("OptionPane.yesButtonText", "Sí");
        UIManager.put("OptionPane.noButtonText", "No");
    }
}
