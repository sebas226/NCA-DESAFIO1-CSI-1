package grupo4_biblioteca;

/**
 * Aquí el libro físico 
 */
public class LibroFisico extends Libro {
    
    // Estantería o zona donde está el libro.
    private String ubicacion;

    // estado del libro
    private String estado;

    public LibroFisico(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor, String ubicacion, String estado) {
        // guardamos los datos comunes del libro, de la clase padre "libro"
        super(idLibro, titulo, genero, cantidadTotal, cantidadDisponible, idAutor);

        // guardamos los datos propios del libro físico.
        this.ubicacion = ubicacion;
        this.estado = estado;
    }

    // devuelve dónde está colocado el libro.
    public String getUbicacion() { 
        return ubicacion; }
    public void setUbicacion(String ubicacion) { 
        this.ubicacion = ubicacion; }

    // devuelve estado del libro.
    public String getEstado() { 
        return estado; }
    public void setEstado(String estado) { 
        this.estado = estado; }

    @Override
    public String obtenerTipoLibro() {
        // método que hay creado en el padre "libro"
        //aparece en el catálogo como "físico"
        return "Físico";
    }
}
