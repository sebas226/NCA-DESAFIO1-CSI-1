package grupo4_biblioteca;

/**
 * Esta clase es abtracta porque hacemos herencia con libro fisico y digital
 * Aquí hay datos generales del libro
 */
public abstract class Libro {
    
    // datos básicos de libro, lo mismo que se pide en la BDs
    private int idLibro;
    private String titulo;
    private String genero;
    private int cantidadTotal;
    private int cantidadDisponible;
    private int idAutor;

    public Libro(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor) {
        
        this.idLibro = idLibro;
        this.titulo = titulo;
        this.genero = genero;
        this.cantidadTotal = cantidadTotal;
        this.cantidadDisponible = cantidadDisponible;
        this.idAutor = idAutor;
    }

    // devuelve id libro
    public int getIdLibro() { 
        return idLibro; }
    public void setIdLibro(int idLibro) { 
        this.idLibro = idLibro; }

    // devuelve titulo libro
    public String getTitulo() { 
        return titulo; }
    public void setTitulo(String titulo) { 
        this.titulo = titulo; }

    // devuelve genero libro
    public String getGenero() { 
        return genero; }
    public void setGenero(String genero) { 
        this.genero = genero; }

    // devuelve copias totales
    public int getCantidadTotal() { 
        return cantidadTotal; }
    public void setCantidadTotal(int cantidadTotal) { 
        this.cantidadTotal = cantidadTotal; }

    // devuelve copias disponibles
    public int getCantidadDisponible() { 
        return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) { 
        this.cantidadDisponible = cantidadDisponible; }

    // devuelve id autor
    public int getIdAutor() { 
        return idAutor; }
    public void setIdAutor(int idAutor) { 
        this.idAutor = idAutor; }
    
    // método que se implementa en las clases hijas "LibroDigital" y "LibroFísico"
    public abstract String obtenerTipoLibro();
}
