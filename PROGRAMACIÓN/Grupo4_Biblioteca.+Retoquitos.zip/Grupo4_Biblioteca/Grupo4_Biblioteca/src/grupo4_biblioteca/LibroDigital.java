package grupo4_biblioteca;

/**
 * Aquí para los libros digitales
 */
public class LibroDigital extends Libro {
    
    // creo el formato del archivo
    private String formato;

    // tamaño del archivo como en la Base de Datos
    private int tamanoArchivo;

    // enlace de ejemplo (el que aparece en la BDs)
    private String enlaceDescarga;

    public LibroDigital(int idLibro, String titulo, String genero, int cantidadTotal, int cantidadDisponible, int idAutor, String formato, int tamanoArchivo, String enlaceDescarga) {
        // guardamos los datos comunes del padre "libro". 
        //"super" hace referencia al padre porque uso herencia
        super(idLibro, titulo, genero, cantidadTotal, cantidadDisponible, idAutor);

        // estos son los datos de libro digital
        this.formato = formato;
        this.tamanoArchivo = tamanoArchivo;
        this.enlaceDescarga = enlaceDescarga;
    }

    // devuelve el formato del archivo.
    public String getFormato() { 
        return formato; }
    public void setFormato(String formato) { 
        this.formato = formato; }

    // devuelve el tamaño del archivo.
    public int getTamanoArchivo() { 
        return tamanoArchivo; }
    public void setTamanoArchivo(int tamanoArchivo) { 
        this.tamanoArchivo = tamanoArchivo; }

    // devuelve el enlace de descarga.
    public String getEnlaceDescarga() { 
        return enlaceDescarga; }
    public void setEnlaceDescarga(String enlaceDescarga) { 
        this.enlaceDescarga = enlaceDescarga; }

    @Override
    public String obtenerTipoLibro() {
        // método que se implementa desde el padre para poner qué tipo de libro es
        //en este caso es "Digital" y esto aparecerá en el catálogo
        return "Digital";
    }
}
