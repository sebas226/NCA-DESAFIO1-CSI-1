package grupo4_biblioteca;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Aquí vemos y gestionamos los usuarios de la Base de Datos
 */

//este apartado se compone de try/catch: intentamos validar unos datoss con el try 
//si no es posible la excepción del actch nos lo hará saber 
public class GestorUsuarios {

    //por si hay error para conectarse a la BDs
    private static String ultimoError = ""; 

    public static Usuario validarUsuario(String nombre, String contrasena) {
        String consultaSql = "SELECT * FROM Usuario WHERE nombre_usuario = ? AND contrasena = ?";

        try (Connection conexion = dbConnection.conectar()) {
            if (conexion == null) {
                ultimoError = "No se pudo conectar con la base de datos.";
                return null;
            }

            try (PreparedStatement consulta = conexion.prepareStatement(consultaSql)) {
                consulta.setString(1, nombre);
                consulta.setString(2, contrasena);

                try (ResultSet resultado = consulta.executeQuery()) {
                    if (resultado.next()) {
                        return hacerUsuario(resultado);
                    }
                }
            }
        } catch (SQLException ex) {
            ultimoError = traducirErrorSql(ex);
            System.out.println("Error al validar usuario: " + ex.getMessage());
        }

        return null;
    }

    public static boolean registrarUsuario(Usuario usuario) {
        ultimoError = "";

        if (usuario == null) {
            ultimoError = "No se han recibido datos del usuario.";
            return false;
        }

        String consultaSql = "INSERT INTO Usuario (nombre_usuario, email, contrasena, telefono, direccion) VALUES (?, ?, ?, ?, ?)";

        try (Connection conexion = dbConnection.conectar()) {
            if (conexion == null) {
                ultimoError = "No se pudo conectar con la base de datos.";
                return false;
            }

            try (PreparedStatement consulta = conexion.prepareStatement(consultaSql)) {
                consulta.setString(1, usuario.getNombreUsuario());
                consulta.setString(2, usuario.getEmail());
                consulta.setString(3, usuario.getContrasena());
                consulta.setString(4, usuario.getTelefono());
                consulta.setString(5, usuario.getDireccion());

                int filasInsertadas = consulta.executeUpdate();
                return filasInsertadas > 0;
            }
        } catch (SQLException ex) {
            ultimoError = traducirErrorSql(ex);
            System.out.println("Error al registrar usuario: " + ex.getMessage());
        }

        return false;
    }

    public static String getUltimoError() {
        return ultimoError;
    }

    private static Usuario hacerUsuario(ResultSet resultado) throws SQLException {
        return new Usuario(
            resultado.getInt("id_usuario"),
            resultado.getString("nombre_usuario"),
            resultado.getString("email"),
            resultado.getString("contrasena"),
            resultado.getString("telefono"),
            resultado.getString("direccion")
        );
    }

    private static String traducirErrorSql(SQLException ex) {
        if (ex.getErrorCode() == 1062) {
            return "Ya existe un usuario con esos datos.";
        }

        if (ex.getMessage() != null && ex.getMessage().contains("Unknown column")) {
            return "Hay una columna mal escrita en la consulta. Revisa que la tabla Usuario tenga los campos: nombre_usuario, email, contrasena, telefono y direccion.";
        }

        if (ex.getMessage() != null && ex.getMessage().contains("Communications link failure")) {
            return "No se pudo conectar con MySQL. Revisa que el servidor esté iniciado.";
        }

        return "No se pudo completar la operación en la base de datos.";
    }
}
