[Setup]
AppName=Biblioteca Grupo 4
AppVersion=1.0
DefaultDirName={pf}\Biblioteca Grupo 4
DefaultGroupName=Biblioteca Grupo 4
OutputDir=C:\Users\nelia\Desktop
OutputBaseFilename=Instalador_Biblioteca_Grupo4
Compression=lzma
SolidCompression=yes

[Files]
Source: "C:\Users\nelia\Desktop\InstaladorBiblioteca_Grupo4\Grupo4_Biblioteca.jar"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\nelia\Desktop\InstaladorBiblioteca_Grupo4\mysql-connector-j-9.6.0.jar"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\nelia\Desktop\InstaladorBiblioteca_Grupo4\README.TXT"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Biblioteca Grupo 4"; Filename: "javaw.exe"; Parameters: "-cp ""{app}\Grupo4_Biblioteca.jar;{app}\mysql-connector-j-9.6.0.jar"" grupo4_biblioteca.Grupo4_Biblioteca"; WorkingDir: "{app}"
Name: "{commondesktop}\Biblioteca Grupo 4"; Filename: "javaw.exe"; Parameters: "-cp ""{app}\Grupo4_Biblioteca.jar;{app}\mysql-connector-j-9.6.0.jar"" grupo4_biblioteca.Grupo4_Biblioteca"; WorkingDir: "{app}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Crear acceso directo en el escritorio"; GroupDescription: "Opciones adicionales:"