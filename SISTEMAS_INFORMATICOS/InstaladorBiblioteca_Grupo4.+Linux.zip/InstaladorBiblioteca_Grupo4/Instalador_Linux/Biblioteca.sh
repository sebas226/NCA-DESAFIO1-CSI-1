#!/bin/bash
cd "$(dirname "$0")"
java -jar Grupo4_Biblioteca.jar
